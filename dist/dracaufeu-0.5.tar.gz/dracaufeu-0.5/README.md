Repository with custom Pytorch functions for personal use.

![](https://www.pokepedia.fr/images/thumb/1/17/Dracaufeu-RFVF.png/250px-Dracaufeu-RFVF.png)
